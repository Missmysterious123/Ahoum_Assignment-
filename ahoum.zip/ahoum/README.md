# Ahoum — Spiritual Sessions Marketplace

A full-stack sessions marketplace where users sign in via Google OAuth, browse sessions, and book them. Creators can host and manage their own sessions.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18 + Vite, React Router v6 |
| Backend | Django 4.2 + Django REST Framework |
| Auth | Google OAuth 2.0 → Backend-issued JWT (SimpleJWT) |
| Database | PostgreSQL 15 |
| Infrastructure | Docker + docker-compose + Nginx reverse proxy |

---

## Quick Start

### 1. Clone the repository

```bash
git clone <your-repo-url> ahoum
cd ahoum
```

### 2. Set up environment variables

```bash
cp .env.example .env
```

Edit `.env` and fill in your values (see **Google OAuth Setup** below).

### 3. Start everything with one command

```bash
docker-compose up --build
```

The app will be available at **http://localhost**

> On first run, Django will automatically run migrations and collect static files.

---

## Google OAuth Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/apis/credentials)
2. Create a new project (or select an existing one)
3. Click **Create Credentials → OAuth 2.0 Client ID**
4. Set **Application type** to **Web application**
5. Add to **Authorized JavaScript origins**:
   ```
   http://localhost
   ```
6. Add to **Authorized redirect URIs**:
   ```
   http://localhost/auth/callback
   ```
7. Copy the **Client ID** and **Client Secret** into your `.env`:
   ```
   GOOGLE_OAUTH2_CLIENT_ID=your-client-id.apps.googleusercontent.com
   GOOGLE_OAUTH2_CLIENT_SECRET=your-client-secret
   ```
8. In the Google Cloud Console sidebar, go to **OAuth consent screen** and add your test email as a **Test user** (required while the app is in testing mode)

---

## Environment Variables Reference

| Variable | Description | Example |
|---|---|---|
| `DJANGO_SECRET_KEY` | Django secret key (keep secret!) | `change-me-in-prod` |
| `DEBUG` | Django debug mode | `False` |
| `ALLOWED_HOSTS` | Comma-separated allowed hosts | `localhost,127.0.0.1` |
| `POSTGRES_DB` | Database name | `ahoum_db` |
| `POSTGRES_USER` | Database user | `ahoum_user` |
| `POSTGRES_PASSWORD` | Database password | `ahoum_password` |
| `GOOGLE_OAUTH2_CLIENT_ID` | Google OAuth Client ID | `*.apps.googleusercontent.com` |
| `GOOGLE_OAUTH2_CLIENT_SECRET` | Google OAuth Client Secret | `GOCSPX-...` |
| `CORS_ALLOWED_ORIGINS` | Allowed CORS origins | `http://localhost` |
| `FRONTEND_URL` | Frontend base URL for redirects | `http://localhost` |

---

## Project Structure

```
ahoum/
├── backend/                    # Django project
│   ├── ahoum_project/          # Django settings, urls, wsgi
│   ├── apps/
│   │   ├── users/              # Custom user model, OAuth, JWT, profile
│   │   ├── sessions_app/       # Session CRUD, creator management
│   │   └── bookings/           # Booking creation & cancellation
│   ├── Dockerfile
│   ├── entrypoint.sh           # Waits for DB, runs migrations, starts gunicorn
│   └── requirements.txt
│
├── frontend/                   # React + Vite
│   ├── src/
│   │   ├── api/                # Axios client with JWT interceptors + auto-refresh
│   │   ├── context/            # AuthContext (global auth state)
│   │   ├── components/         # Navbar, SessionCard
│   │   ├── pages/              # Home, SessionDetail, Login, AuthCallback,
│   │   │                       # UserDashboard, CreatorDashboard, Profile
│   │   └── styles/             # Global CSS variables & utilities
│   ├── Dockerfile              # Multi-stage: build → nginx
│   └── nginx-frontend.conf     # SPA fallback routing
│
├── nginx/
│   └── nginx.conf              # Reverse proxy: /api/ → Django, / → React
│
├── docker-compose.yml          # 4 containers: db, backend, frontend, nginx
├── .env.example                # All required environment variables
└── README.md
```

---

## API Endpoints

### Auth
| Method | URL | Description |
|---|---|---|
| `POST` | `/api/auth/google/callback/` | Exchange Google code for JWT |
| `POST` | `/api/auth/token/refresh/` | Refresh access token |
| `GET` | `/api/auth/profile/` | Get current user profile |
| `PATCH` | `/api/auth/profile/` | Update profile |
| `POST` | `/api/auth/switch-role/` | Switch between user/creator role |

### Sessions
| Method | URL | Auth | Description |
|---|---|---|---|
| `GET` | `/api/sessions/` | Public | List published sessions (filterable) |
| `GET` | `/api/sessions/<id>/` | Public | Session detail |
| `GET` | `/api/sessions/my/` | Creator | List own sessions |
| `POST` | `/api/sessions/my/` | Creator | Create a session |
| `PATCH` | `/api/sessions/my/<id>/` | Creator | Update own session |
| `DELETE` | `/api/sessions/my/<id>/` | Creator | Delete own session |
| `GET` | `/api/sessions/my/bookings/` | Creator | All bookings on own sessions |

### Bookings
| Method | URL | Auth | Description |
|---|---|---|---|
| `GET` | `/api/bookings/` | User | List own bookings (`?status=active\|past`) |
| `POST` | `/api/bookings/` | User | Book a session |
| `POST` | `/api/bookings/<id>/cancel/` | User | Cancel a booking |

---

## Demo Flow

### As a User (browse & book)

1. Open **http://localhost** — you'll see the public sessions catalog
2. Click **Sign in** → **Continue with Google**
3. After login, you land on the home page as a **User**
4. Click any session card to view its details
5. Click **Book Now** — you're now booked!
6. Click **My Bookings** in the navbar to see your booking
7. You can cancel an upcoming booking from the dashboard

### As a Creator (host sessions)

1. Sign in with Google
2. Go to **Profile** → click **Switch to Creator**
3. Your navbar now shows **Creator Dashboard**
4. Click **+ New Session** and fill in the form (title, date, price, etc.)
5. Your session is now live in the public catalog
6. Switch back to the **Bookings Received** tab to see who has booked

---

## Development (without Docker)

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Set env vars (or create a .env and load it)
export POSTGRES_HOST=localhost
export POSTGRES_DB=ahoum_db
export POSTGRES_USER=ahoum_user
export POSTGRES_PASSWORD=ahoum_password
export DJANGO_SECRET_KEY=dev-secret
export GOOGLE_OAUTH2_CLIENT_ID=your-client-id
export GOOGLE_OAUTH2_CLIENT_SECRET=your-client-secret

python manage.py migrate
python manage.py runserver
```

### Frontend

```bash
cd frontend
npm install

# Create a .env.local
echo "VITE_GOOGLE_CLIENT_ID=your-client-id" > .env.local
echo "VITE_API_URL=http://localhost:8000/api" >> .env.local

npm run dev
```

---

## Useful Docker Commands

```bash
# Start all services
docker-compose up --build

# Run in background
docker-compose up -d --build

# View backend logs
docker-compose logs -f backend

# Create a Django superuser
docker-compose exec backend python manage.py createsuperuser

# Open Django shell
docker-compose exec backend python manage.py shell

# Stop all services
docker-compose down

# Stop and remove volumes (resets DB)
docker-compose down -v
```

---

## Scoring Checklist

| Category | Implementation |
|---|---|
| **Architecture & Docker (20pts)** | 4 containers (db, backend, frontend, nginx), single `docker-compose up --build`, named volumes, health checks |
| **Auth & Roles (20pts)** | Google OAuth → backend JWT, two roles (user/creator), role enforcement on all endpoints, role-switch feature |
| **Core Features (30pts)** | Session CRUD, public catalog with search/filter, booking with conflict/capacity checks, user & creator dashboards |
| **Frontend UX (15pts)** | Responsive design, loading states, error handling, empty states, sticky booking card |
| **Code Quality & Docs (15pts)** | `.env.example`, this README, clean app structure, serializer/view separation |
