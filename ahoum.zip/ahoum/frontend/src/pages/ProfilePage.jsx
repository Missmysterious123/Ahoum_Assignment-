import { useState } from 'react';
import { authApi } from '../api';
import { useAuth } from '../context/AuthContext';
import './ProfilePage.css';

export default function ProfilePage() {
  const { user, refreshUser, switchRole } = useAuth();
  const [form, setForm] = useState({
    first_name: user?.first_name || '',
    last_name: user?.last_name || '',
    username: user?.username || '',
    bio: user?.bio || '',
    avatar: user?.avatar || '',
  });
  const [saving, setSaving] = useState(false);
  const [switching, setSwitching] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  const f = (k) => (e) => setForm(prev => ({ ...prev, [k]: e.target.value }));

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true); setSuccess(''); setError('');
    try {
      await authApi.updateProfile(form);
      await refreshUser();
      setSuccess('Profile updated successfully!');
    } catch {
      setError('Failed to update profile.');
    } finally {
      setSaving(false);
    }
  };

  const handleRoleSwitch = async () => {
    const newRole = user.role === 'user' ? 'creator' : 'user';
    setSwitching(true); setError('');
    try {
      await switchRole(newRole);
      setSuccess(`Switched to ${newRole} role!`);
    } catch {
      setError('Failed to switch role.');
    } finally {
      setSwitching(false);
    }
  };

  return (
    <div className="page container">
      <div className="profile-layout">
        <div className="profile-sidebar">
          <div className="profile-avatar-section">
            {user?.avatar
              ? <img src={user.avatar} alt={user.first_name} className="profile-avatar-img" />
              : <div className="profile-avatar-placeholder">{(user?.first_name || user?.email || '?')[0].toUpperCase()}</div>
            }
            <h2 className="profile-name">{user?.first_name} {user?.last_name}</h2>
            <p className="profile-email">{user?.email}</p>
            <span className={`badge ${user?.role === 'creator' ? 'badge-terracotta' : 'badge-forest'}`}>
              {user?.role}
            </span>
          </div>

          <div className="role-switch-section">
            <h3>Switch Role</h3>
            <p>You are currently a <strong>{user?.role}</strong>.</p>
            <button
              className={`btn ${user?.role === 'user' ? 'btn-terracotta btn-primary' : 'btn-forest'}`}
              onClick={handleRoleSwitch}
              disabled={switching}
            >
              {switching ? 'Switching…' : `Switch to ${user?.role === 'user' ? 'Creator' : 'User'}`}
            </button>
            <p className="role-note">
              {user?.role === 'user'
                ? 'Creators can host and manage sessions.'
                : 'Switch to User to browse and book sessions.'}
            </p>
          </div>
        </div>

        <div className="profile-form-section">
          <h1 className="dashboard-title">Edit Profile</h1>
          {success && <div className="alert alert-success">{success}</div>}
          {error && <div className="alert alert-error">{error}</div>}

          <form onSubmit={handleSave} className="profile-form">
            <div className="form-row">
              <div className="form-group">
                <label>First Name</label>
                <input className="form-input" value={form.first_name} onChange={f('first_name')} />
              </div>
              <div className="form-group">
                <label>Last Name</label>
                <input className="form-input" value={form.last_name} onChange={f('last_name')} />
              </div>
            </div>
            <div className="form-group">
              <label>Username</label>
              <input className="form-input" value={form.username} onChange={f('username')} />
            </div>
            <div className="form-group">
              <label>Bio</label>
              <textarea className="form-input" value={form.bio} onChange={f('bio')} placeholder="Tell us about yourself…" />
            </div>
            <div className="form-group">
              <label>Avatar URL</label>
              <input className="form-input" value={form.avatar} onChange={f('avatar')} placeholder="https://…" />
            </div>
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? 'Saving…' : 'Save Changes'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
