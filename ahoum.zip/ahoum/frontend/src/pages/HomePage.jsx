import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { sessionsApi } from '../api';
import { useAuth } from '../context/AuthContext';
import SessionCard from '../components/sessions/SessionCard';
import '../components/sessions/SessionCard.css';
import './HomePage.css';

const CATEGORIES = ['All', 'Meditation', 'Yoga', 'Breathwork', 'Healing', 'Astrology'];

export default function HomePage() {
  const { user } = useAuth();
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');

  useEffect(() => {
    setLoading(true);
    const params = {};
    if (category !== 'All') params.category = category;
    if (search) params.search = search;
    sessionsApi.list(params)
      .then(({ data }) => setSessions(data.results || data))
      .catch(() => setError('Failed to load sessions.'))
      .finally(() => setLoading(false));
  }, [category, search]);

  const handleSearch = (e) => {
    e.preventDefault();
    setSearch(searchInput);
  };

  return (
    <div>
      {/* Hero */}
      <section className="hero">
        <div className="hero-inner container">
          <p className="hero-eyebrow">Curated Spiritual Experiences</p>
          <h1 className="hero-title">Find Your <em>Inner</em> Practice</h1>
          <p className="hero-subtitle">
            Browse live sessions led by experienced guides — meditation, yoga, breathwork, and more.
          </p>
          {!user && (
            <Link to="/login" className="btn btn-primary hero-cta">
              Begin Your Journey
            </Link>
          )}
        </div>
        <div className="hero-decoration">
          <div className="hero-orb hero-orb-1" />
          <div className="hero-orb hero-orb-2" />
        </div>
      </section>

      {/* Filters */}
      <section className="filters-section container">
        <form onSubmit={handleSearch} className="search-form">
          <input
            className="form-input search-input"
            placeholder="Search sessions…"
            value={searchInput}
            onChange={e => setSearchInput(e.target.value)}
          />
          <button type="submit" className="btn btn-primary">Search</button>
          {search && (
            <button type="button" className="btn btn-ghost"
              onClick={() => { setSearch(''); setSearchInput(''); }}>Clear</button>
          )}
        </form>

        <div className="category-pills">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              className={`category-pill ${category === cat ? 'active' : ''}`}
              onClick={() => setCategory(cat)}
            >{cat}</button>
          ))}
        </div>
      </section>

      {/* Sessions grid */}
      <section className="container" style={{ paddingBottom: '4rem' }}>
        {loading ? (
          <div className="loading-inline">
            <div className="spinner" /> Loading sessions…
          </div>
        ) : error ? (
          <div className="alert alert-error">{error}</div>
        ) : sessions.length === 0 ? (
          <div className="empty-state">
            <h3>No sessions found</h3>
            <p>Try a different category or search term.</p>
          </div>
        ) : (
          <div className="sessions-grid">
            {sessions.map(s => <SessionCard key={s.id} session={s} />)}
          </div>
        )}
      </section>
    </div>
  );
}
