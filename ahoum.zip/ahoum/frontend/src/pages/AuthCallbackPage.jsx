import { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { authApi } from '../api';
import { useAuth } from '../context/AuthContext';

export default function AuthCallbackPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const called = useRef(false);

  useEffect(() => {
    if (called.current) return;
    called.current = true;

    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const error = params.get('error');

    if (error || !code) {
      navigate('/login?error=oauth_failed');
      return;
    }

    const redirectUri = `${window.location.origin}/auth/callback`;

    authApi.googleCallback(code, redirectUri)
      .then(({ data }) => {
        login(data.tokens, data.user);
        navigate('/');
      })
      .catch(() => navigate('/login?error=auth_failed'));
  }, []);

  return (
    <div className="loading-screen">
      <div style={{ textAlign: 'center' }}>
        <div className="spinner" style={{ margin: '0 auto 1rem' }} />
        <p style={{ color: 'var(--muted)', fontFamily: 'var(--font-serif)', fontSize: '1.1rem' }}>
          Signing you in…
        </p>
      </div>
    </div>
  );
}
