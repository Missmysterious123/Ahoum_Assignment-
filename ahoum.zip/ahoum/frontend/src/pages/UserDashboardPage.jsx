import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { bookingsApi } from '../api';
import { useAuth } from '../context/AuthContext';
import './DashboardPage.css';

function formatDate(dt) {
  return new Date(dt).toLocaleDateString('en-IN', {
    day: 'numeric', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

export default function UserDashboardPage() {
  const { user } = useAuth();
  const [tab, setTab] = useState('active');
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [cancelling, setCancelling] = useState(null);
  const [error, setError] = useState('');

  const fetchBookings = () => {
    setLoading(true);
    bookingsApi.list({ status: tab })
      .then(({ data }) => setBookings(data.results || data))
      .catch(() => setError('Failed to load bookings.'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { fetchBookings(); }, [tab]);

  const handleCancel = async (id) => {
    if (!confirm('Cancel this booking?')) return;
    setCancelling(id);
    try {
      await bookingsApi.cancel(id);
      fetchBookings();
    } catch (e) {
      setError('Failed to cancel booking.');
    } finally {
      setCancelling(null);
    }
  };

  return (
    <div className="page container">
      <div className="dashboard-header">
        <div>
          <h1 className="dashboard-title">My Bookings</h1>
          <p className="dashboard-sub">Welcome back, {user?.first_name || user?.email}</p>
        </div>
        <Link to="/" className="btn btn-secondary">Browse Sessions</Link>
      </div>

      <div className="tab-bar">
        <button className={`tab-btn ${tab === 'active' ? 'active' : ''}`} onClick={() => setTab('active')}>Upcoming</button>
        <button className={`tab-btn ${tab === 'past' ? 'active' : ''}`} onClick={() => setTab('past')}>Past</button>
        <button className={`tab-btn ${tab === '' ? 'active' : ''}`} onClick={() => setTab('')}>All</button>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {loading ? (
        <div className="loading-inline"><div className="spinner" /> Loading…</div>
      ) : bookings.length === 0 ? (
        <div className="empty-state">
          <h3>No bookings yet</h3>
          <p>Explore sessions and book your first one.</p>
          <Link to="/" className="btn btn-primary" style={{ marginTop: '1rem' }}>Explore Sessions</Link>
        </div>
      ) : (
        <div className="booking-list">
          {bookings.map(b => (
            <div key={b.id} className={`booking-item card ${b.status === 'cancelled' ? 'cancelled' : ''}`}>
              <div className="booking-item-img">
                {b.session.cover_image
                  ? <img src={b.session.cover_image} alt={b.session.title} />
                  : <div className="booking-img-placeholder">☽</div>
                }
              </div>
              <div className="booking-item-info">
                <Link to={`/sessions/${b.session.id}`} className="booking-item-title">
                  {b.session.title}
                </Link>
                <p className="booking-item-creator">
                  by {b.session.creator?.first_name} {b.session.creator?.last_name}
                </p>
                <p className="booking-item-date">📅 {formatDate(b.session.scheduled_at)}</p>
                <p className="booking-item-date">⏱ {b.session.duration_minutes} min</p>
              </div>
              <div className="booking-item-actions">
                <span className={`badge ${b.status === 'confirmed' ? 'badge-forest' : 'badge-muted'}`}>
                  {b.status}
                </span>
                {b.status === 'confirmed' && new Date(b.session.scheduled_at) > new Date() && (
                  <button
                    className="btn btn-danger"
                    onClick={() => handleCancel(b.id)}
                    disabled={cancelling === b.id}
                    style={{ fontSize: '0.82rem', padding: '0.4rem 0.9rem' }}
                  >
                    {cancelling === b.id ? '…' : 'Cancel'}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
