import { useState, useEffect } from 'react';
import { sessionsApi } from '../api';
import { useAuth } from '../context/AuthContext';
import './DashboardPage.css';

function formatDate(dt) {
  return new Date(dt).toLocaleDateString('en-IN', {
    day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

const EMPTY_FORM = {
  title: '', description: '', category: '', price: '0',
  duration_minutes: '60', scheduled_at: '', max_participants: '10',
  status: 'published', cover_image: '',
};

export default function CreatorDashboardPage() {
  const { user } = useAuth();
  const [tab, setTab] = useState('sessions');
  const [sessions, setSessions] = useState([]);
  const [creatorBookings, setCreatorBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editSession, setEditSession] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const fetchSessions = () => {
    setLoading(true);
    sessionsApi.mySessions()
      .then(({ data }) => setSessions(data.results || data))
      .catch(() => setError('Failed to load sessions.'))
      .finally(() => setLoading(false));
  };

  const fetchBookings = () => {
    setLoading(true);
    sessionsApi.myBookings()
      .then(({ data }) => setCreatorBookings(data.results || data))
      .catch(() => setError('Failed to load bookings.'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { tab === 'sessions' ? fetchSessions() : fetchBookings(); }, [tab]);

  const openCreate = () => { setEditSession(null); setForm(EMPTY_FORM); setShowModal(true); setError(''); };
  const openEdit = (s) => {
    setEditSession(s);
    setForm({
      title: s.title, description: s.description, category: s.category || '',
      price: s.price, duration_minutes: s.duration_minutes,
      scheduled_at: s.scheduled_at?.slice(0, 16),
      max_participants: s.max_participants, status: s.status,
      cover_image: s.cover_image || '',
    });
    setShowModal(true); setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true); setError(''); setSuccess('');
    try {
      if (editSession) {
        await sessionsApi.update(editSession.id, form);
        setSuccess('Session updated!');
      } else {
        await sessionsApi.create(form);
        setSuccess('Session created!');
      }
      setShowModal(false);
      fetchSessions();
    } catch (e) {
      const data = e.response?.data;
      setError(typeof data === 'object' ? Object.values(data).flat().join(' ') : 'Failed to save session.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this session? This cannot be undone.')) return;
    try {
      await sessionsApi.delete(id);
      fetchSessions();
    } catch { setError('Failed to delete session.'); }
  };

  const f = (k) => (e) => setForm(prev => ({ ...prev, [k]: e.target.value }));

  return (
    <div className="page container">
      <div className="dashboard-header">
        <div>
          <h1 className="dashboard-title">Creator Dashboard</h1>
          <p className="dashboard-sub">Manage your sessions and view bookings</p>
        </div>
        {tab === 'sessions' && (
          <button className="btn btn-primary" onClick={openCreate}>+ New Session</button>
        )}
      </div>

      {success && <div className="alert alert-success">{success}</div>}
      {error && !showModal && <div className="alert alert-error">{error}</div>}

      <div className="tab-bar">
        <button className={`tab-btn ${tab === 'sessions' ? 'active' : ''}`} onClick={() => setTab('sessions')}>My Sessions</button>
        <button className={`tab-btn ${tab === 'bookings' ? 'active' : ''}`} onClick={() => setTab('bookings')}>Bookings Received</button>
      </div>

      {loading ? (
        <div className="loading-inline"><div className="spinner" /> Loading…</div>
      ) : tab === 'sessions' ? (
        sessions.length === 0 ? (
          <div className="empty-state">
            <h3>No sessions yet</h3>
            <p>Create your first session to get started.</p>
            <button className="btn btn-primary" style={{ marginTop: '1rem' }} onClick={openCreate}>Create Session</button>
          </div>
        ) : (
          <div className="sessions-manage-list">
            {sessions.map(s => (
              <div key={s.id} className="session-manage-item card">
                <div className="session-manage-info">
                  <div className="session-manage-title">{s.title}</div>
                  <div className="session-manage-meta">
                    <span>📅 {formatDate(s.scheduled_at)}</span>
                    <span>👥 {s.max_participants - s.available_spots}/{s.max_participants} booked</span>
                    <span>💰 {s.price === '0.00' ? 'Free' : `₹${s.price}`}</span>
                    <span className={`badge ${s.status === 'published' ? 'badge-forest' : 'badge-muted'}`}>{s.status}</span>
                  </div>
                </div>
                <div className="session-manage-actions">
                  <button className="btn btn-ghost" style={{ fontSize: '0.82rem', padding: '0.4rem 0.9rem' }} onClick={() => openEdit(s)}>Edit</button>
                  <button className="btn btn-danger" style={{ fontSize: '0.82rem', padding: '0.4rem 0.9rem' }} onClick={() => handleDelete(s.id)}>Delete</button>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        creatorBookings.length === 0 ? (
          <div className="empty-state"><h3>No bookings yet</h3><p>Bookings for your sessions will appear here.</p></div>
        ) : (
          <div className="booking-list">
            {creatorBookings.map(b => (
              <div key={b.id} className="booking-item card">
                <div className="booking-item-info">
                  <span className="booking-item-title">{b.session?.title}</span>
                  <span className="booking-item-creator">Booked by: {b.user?.first_name} {b.user?.last_name} ({b.user?.email})</span>
                  <span className="booking-item-date">📅 Session: {formatDate(b.session?.scheduled_at)}</span>
                  <span className="booking-item-date">🕒 Booked on: {formatDate(b.booked_at)}</span>
                </div>
                <div className="booking-item-actions">
                  <span className={`badge ${b.status === 'confirmed' ? 'badge-forest' : 'badge-muted'}`}>{b.status}</span>
                </div>
              </div>
            ))}
          </div>
        )
      )}

      {/* Create/Edit Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h2>{editSession ? 'Edit Session' : 'Create Session'}</h2>
            {error && <div className="alert alert-error">{error}</div>}
            <form className="modal-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Title *</label>
                <input className="form-input" required value={form.title} onChange={f('title')} placeholder="e.g. Morning Breathwork" />
              </div>
              <div className="form-group">
                <label>Description *</label>
                <textarea className="form-input" required value={form.description} onChange={f('description')} placeholder="Describe your session…" />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                <div className="form-group">
                  <label>Category</label>
                  <input className="form-input" value={form.category} onChange={f('category')} placeholder="e.g. Meditation" />
                </div>
                <div className="form-group">
                  <label>Price (₹)</label>
                  <input className="form-input" type="number" min="0" step="0.01" value={form.price} onChange={f('price')} />
                </div>
                <div className="form-group">
                  <label>Duration (min)</label>
                  <input className="form-input" type="number" min="15" value={form.duration_minutes} onChange={f('duration_minutes')} />
                </div>
                <div className="form-group">
                  <label>Max Participants</label>
                  <input className="form-input" type="number" min="1" value={form.max_participants} onChange={f('max_participants')} />
                </div>
              </div>
              <div className="form-group">
                <label>Scheduled At *</label>
                <input className="form-input" type="datetime-local" required value={form.scheduled_at} onChange={f('scheduled_at')} />
              </div>
              <div className="form-group">
                <label>Cover Image URL</label>
                <input className="form-input" value={form.cover_image} onChange={f('cover_image')} placeholder="https://…" />
              </div>
              <div className="form-group">
                <label>Status</label>
                <select className="form-input" value={form.status} onChange={f('status')}>
                  <option value="published">Published</option>
                  <option value="draft">Draft</option>
                </select>
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>
                  {saving ? 'Saving…' : editSession ? 'Update Session' : 'Create Session'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
