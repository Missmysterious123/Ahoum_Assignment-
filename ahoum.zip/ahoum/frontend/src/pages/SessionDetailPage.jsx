import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { sessionsApi, bookingsApi } from '../api';
import { useAuth } from '../context/AuthContext';
import './SessionDetailPage.css';

function formatDate(dt) {
  return new Date(dt).toLocaleDateString('en-IN', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

export default function SessionDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [booking, setBooking] = useState(false);
  const [booked, setBooked] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    sessionsApi.detail(id)
      .then(({ data }) => { setSession(data); setBooked(data.is_booked_by_me); })
      .catch(() => setError('Session not found.'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleBook = async () => {
    if (!user) { navigate('/login'); return; }
    setBooking(true); setError(''); setSuccess('');
    try {
      await bookingsApi.create(id);
      setBooked(true);
      setSuccess('Session booked successfully!');
      setSession(s => ({ ...s, available_spots: s.available_spots - 1 }));
    } catch (e) {
      setError(e.response?.data?.detail || e.response?.data?.[0] || 'Booking failed.');
    } finally {
      setBooking(false);
    }
  };

  if (loading) return <div className="loading-screen"><div className="spinner" /></div>;
  if (error && !session) return (
    <div className="container page"><div className="alert alert-error">{error}</div></div>
  );
  if (!session) return null;

  const isPast = new Date(session.scheduled_at) < new Date();
  const isOwner = user && session.creator?.id === user.id;
  const canBook = user && !booked && !session.is_full && !isPast && !isOwner && user.role !== 'creator';

  return (
    <div className="session-detail-page">
      {/* Cover */}
      <div className="session-detail-cover">
        {session.cover_image
          ? <img src={session.cover_image} alt={session.title} />
          : <div className="session-detail-cover-placeholder">☽</div>
        }
        <div className="session-detail-cover-overlay" />
      </div>

      <div className="container">
        <div className="session-detail-layout">
          {/* Main */}
          <div className="session-detail-main">
            {session.category && (
              <span className="badge badge-terracotta" style={{ marginBottom: '1rem', display: 'inline-flex' }}>
                {session.category}
              </span>
            )}
            <h1 className="session-detail-title">{session.title}</h1>
            <p className="session-detail-creator">
              Led by <strong>{session.creator?.first_name} {session.creator?.last_name}</strong>
            </p>
            <hr className="divider" />
            <h2 className="section-label">About this session</h2>
            <p className="session-detail-description">{session.description}</p>
          </div>

          {/* Sidebar booking card */}
          <div className="session-detail-sidebar">
            <div className="booking-card card">
              <div className="booking-card-body">
                <div className="booking-card-price">
                  {session.price === '0.00' || session.price === 0 ? 'Free' : `₹${session.price}`}
                </div>

                <div className="booking-info-row">
                  <span className="booking-info-label">📅 Date</span>
                  <span>{formatDate(session.scheduled_at)}</span>
                </div>
                <div className="booking-info-row">
                  <span className="booking-info-label">⏱ Duration</span>
                  <span>{session.duration_minutes} min</span>
                </div>
                <div className="booking-info-row">
                  <span className="booking-info-label">👥 Spots</span>
                  <span>{session.available_spots} / {session.max_participants} available</span>
                </div>

                {error && <div className="alert alert-error">{error}</div>}
                {success && <div className="alert alert-success">{success}</div>}

                {!user ? (
                  <Link to="/login" className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
                    Sign in to Book
                  </Link>
                ) : booked ? (
                  <div className="booked-badge">✓ You're booked!</div>
                ) : isOwner ? (
                  <div className="alert alert-success" style={{ textAlign: 'center', margin: 0 }}>You own this session</div>
                ) : isPast ? (
                  <div className="badge badge-muted" style={{ justifyContent: 'center', padding: '0.75rem' }}>Session has ended</div>
                ) : session.is_full ? (
                  <div className="badge badge-muted" style={{ justifyContent: 'center', padding: '0.75rem' }}>Fully booked</div>
                ) : user.role === 'creator' ? (
                  <p className="booking-note">Switch to User role to book sessions.</p>
                ) : (
                  <button
                    className="btn btn-primary"
                    style={{ width: '100%', justifyContent: 'center' }}
                    onClick={handleBook}
                    disabled={booking}
                  >
                    {booking ? 'Booking…' : 'Book Now'}
                  </button>
                )}
              </div>
            </div>
            <Link to="/" className="back-link">← Back to sessions</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
