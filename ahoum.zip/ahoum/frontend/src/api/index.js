import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || '/api';

const api = axios.create({
  baseURL: API_BASE,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT access token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Auto-refresh on 401
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      const refresh = localStorage.getItem('refresh_token');
      if (refresh) {
        try {
          const { data } = await axios.post(`${API_BASE}/auth/token/refresh/`, { refresh });
          localStorage.setItem('access_token', data.access);
          original.headers.Authorization = `Bearer ${data.access}`;
          return api(original);
        } catch {
          localStorage.clear();
          window.location.href = '/login';
        }
      }
    }
    return Promise.reject(error);
  }
);

// ── Auth ───────────────────────────────────────────────────────────────────
export const authApi = {
  googleCallback: (code, redirectUri) =>
    api.post('/auth/google/callback/', { code, redirect_uri: redirectUri }),
  getProfile: () => api.get('/auth/profile/'),
  updateProfile: (data) => api.patch('/auth/profile/', data),
  switchRole: (role) => api.post('/auth/switch-role/', { role }),
  refreshToken: (refresh) => api.post('/auth/token/refresh/', { refresh }),
};

// ── Sessions ───────────────────────────────────────────────────────────────
export const sessionsApi = {
  list: (params) => api.get('/sessions/', { params }),
  detail: (id) => api.get(`/sessions/${id}/`),
  // Creator endpoints
  mySessions: () => api.get('/sessions/my/'),
  create: (data) => api.post('/sessions/my/', data),
  update: (id, data) => api.patch(`/sessions/my/${id}/`, data),
  delete: (id) => api.delete(`/sessions/my/${id}/`),
  myBookings: () => api.get('/sessions/my/bookings/'),
};

// ── Bookings ───────────────────────────────────────────────────────────────
export const bookingsApi = {
  list: (params) => api.get('/bookings/', { params }),
  create: (sessionId) => api.post('/bookings/', { session_id: sessionId }),
  cancel: (id) => api.post(`/bookings/${id}/cancel/`),
};

export default api;
