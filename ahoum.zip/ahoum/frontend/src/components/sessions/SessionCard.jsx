import { Link } from 'react-router-dom';

const CATEGORY_COLORS = {
  meditation: 'badge-forest',
  yoga: 'badge-terracotta',
  breathwork: 'badge-gold',
  default: 'badge-muted',
};

function formatDate(dt) {
  return new Date(dt).toLocaleDateString('en-IN', {
    day: 'numeric', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  });
}

export default function SessionCard({ session }) {
  const badgeClass = CATEGORY_COLORS[session.category?.toLowerCase()] || CATEGORY_COLORS.default;
  const isPast = new Date(session.scheduled_at) < new Date();

  return (
    <Link to={`/sessions/${session.id}`} className="session-card card">
      <div className="session-card-img">
        {session.cover_image
          ? <img src={session.cover_image} alt={session.title} />
          : <div className="session-card-img-placeholder">☽</div>
        }
        {isPast && <div className="session-card-past-badge">Past</div>}
      </div>
      <div className="session-card-body">
        <div className="session-card-meta">
          {session.category && (
            <span className={`badge ${badgeClass}`}>{session.category}</span>
          )}
          {session.is_full && !isPast && (
            <span className="badge badge-muted">Full</span>
          )}
        </div>
        <h3 className="session-card-title">{session.title}</h3>
        <p className="session-card-creator">
          by {session.creator?.first_name || session.creator?.username}
        </p>
        <p className="session-card-date">{formatDate(session.scheduled_at)}</p>
        <div className="session-card-footer">
          <span className="session-card-price">
            {session.price === '0.00' || session.price === 0
              ? 'Free' : `₹${session.price}`}
          </span>
          <span className="session-card-spots">
            {session.available_spots} spot{session.available_spots !== 1 ? 's' : ''} left
          </span>
        </div>
      </div>
    </Link>
  );
}
