import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import './Navbar.css';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="navbar-brand">
          <span className="brand-symbol">☽</span>
          <span className="brand-text">Ahoum</span>
        </Link>

        <div className="navbar-links">
          <Link to="/" className="nav-link">Sessions</Link>
          {user ? (
            <>
              {user.role === 'creator' ? (
                <Link to="/creator" className="nav-link">Creator Dashboard</Link>
              ) : (
                <Link to="/dashboard" className="nav-link">My Bookings</Link>
              )}
              <Link to="/profile" className="nav-link">Profile</Link>
              <div className="nav-avatar">
                {user.avatar
                  ? <img src={user.avatar} alt={user.first_name} className="avatar-img" />
                  : <div className="avatar-placeholder">{(user.first_name || user.email)[0].toUpperCase()}</div>
                }
              </div>
              <button onClick={handleLogout} className="btn btn-ghost btn-sm">Sign out</button>
            </>
          ) : (
            <Link to="/login" className="btn btn-primary btn-sm">Sign in</Link>
          )}
        </div>
      </div>
    </nav>
  );
}
