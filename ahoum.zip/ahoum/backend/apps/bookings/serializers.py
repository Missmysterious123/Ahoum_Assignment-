from rest_framework import serializers
from .models import Booking
from apps.sessions_app.serializers import SessionSerializer
from apps.users.serializers import UserSerializer


class BookingSerializer(serializers.ModelSerializer):
    session = SessionSerializer(read_only=True)
    user = UserSerializer(read_only=True)
    session_id = serializers.PrimaryKeyRelatedField(
        queryset=__import__('apps.sessions_app.models', fromlist=['Session']).Session.objects.all(),
        source='session',
        write_only=True
    )

    class Meta:
        model = Booking
        fields = ['id', 'user', 'session', 'session_id', 'status', 'booked_at', 'notes']
        read_only_fields = ['id', 'user', 'booked_at', 'status']
