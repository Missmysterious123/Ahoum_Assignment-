from rest_framework import generics, permissions, status
from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.utils import timezone
from .models import Booking
from .serializers import BookingSerializer
from apps.sessions_app.models import Session


class BookingListCreateView(generics.ListCreateAPIView):
    """User: list their bookings and create new ones."""
    serializer_class = BookingSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        queryset = Booking.objects.filter(
            user=self.request.user
        ).select_related('session', 'session__creator', 'user')

        status_param = self.request.query_params.get('status')
        if status_param == 'active':
            queryset = queryset.filter(
                status='confirmed',
                session__scheduled_at__gte=timezone.now()
            )
        elif status_param == 'past':
            queryset = queryset.filter(
                session__scheduled_at__lt=timezone.now()
            )
        return queryset

    def perform_create(self, serializer):
        session = serializer.validated_data['session']

        # Prevent duplicate bookings
        if Booking.objects.filter(user=self.request.user, session=session, status='confirmed').exists():
            from rest_framework.exceptions import ValidationError
            raise ValidationError('You have already booked this session.')

        # Check availability
        if session.is_full:
            from rest_framework.exceptions import ValidationError
            raise ValidationError('This session is fully booked.')

        # Prevent creators from booking their own sessions
        if session.creator == self.request.user:
            from rest_framework.exceptions import ValidationError
            raise ValidationError('You cannot book your own session.')

        serializer.save(user=self.request.user, status='confirmed')


class BookingCancelView(APIView):
    """User: cancel a booking."""
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, pk):
        booking = get_object_or_404(Booking, pk=pk, user=request.user)
        if booking.status == 'cancelled':
            return Response({'error': 'Booking is already cancelled.'}, status=status.HTTP_400_BAD_REQUEST)
        booking.status = 'cancelled'
        booking.save()
        return Response(BookingSerializer(booking).data)
