from rest_framework import serializers
from .models import Session
from apps.users.serializers import UserSerializer


class SessionSerializer(serializers.ModelSerializer):
    creator = UserSerializer(read_only=True)
    available_spots = serializers.ReadOnlyField()
    is_full = serializers.ReadOnlyField()
    is_booked_by_me = serializers.SerializerMethodField()

    class Meta:
        model = Session
        fields = [
            'id', 'creator', 'title', 'description', 'category',
            'price', 'duration_minutes', 'scheduled_at', 'max_participants',
            'status', 'cover_image', 'available_spots', 'is_full',
            'is_booked_by_me', 'created_at', 'updated_at'
        ]
        read_only_fields = ['id', 'creator', 'created_at', 'updated_at']

    def get_is_booked_by_me(self, obj):
        request = self.context.get('request')
        if request and request.user.is_authenticated:
            return obj.bookings.filter(user=request.user, status='confirmed').exists()
        return False


class SessionCreateUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Session
        fields = [
            'title', 'description', 'category', 'price',
            'duration_minutes', 'scheduled_at', 'max_participants',
            'status', 'cover_image'
        ]
