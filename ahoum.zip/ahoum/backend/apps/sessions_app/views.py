from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.shortcuts import get_object_or_404
from .models import Session
from .serializers import SessionSerializer, SessionCreateUpdateSerializer


class IsCreator(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'creator'


class IsCreatorOrReadOnly(permissions.BasePermission):
    def has_permission(self, request, view):
        if request.method in permissions.SAFE_METHODS:
            return True
        return request.user.is_authenticated and request.user.role == 'creator'

    def has_object_permission(self, request, view, obj):
        if request.method in permissions.SAFE_METHODS:
            return True
        return obj.creator == request.user


class SessionListView(generics.ListAPIView):
    """Public catalog of published sessions."""
    serializer_class = SessionSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        queryset = Session.objects.filter(status='published').select_related('creator')
        category = self.request.query_params.get('category')
        search = self.request.query_params.get('search')
        if category:
            queryset = queryset.filter(category__iexact=category)
        if search:
            queryset = queryset.filter(title__icontains=search)
        return queryset


class SessionDetailView(generics.RetrieveAPIView):
    """Public session detail."""
    serializer_class = SessionSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        return Session.objects.filter(status='published').select_related('creator')


class CreatorSessionListCreateView(generics.ListCreateAPIView):
    """Creator: list own sessions + create new ones."""
    permission_classes = [IsCreator]

    def get_serializer_class(self):
        if self.request.method == 'POST':
            return SessionCreateUpdateSerializer
        return SessionSerializer

    def get_queryset(self):
        return Session.objects.filter(creator=self.request.user).select_related('creator')

    def perform_create(self, serializer):
        serializer.save(creator=self.request.user)

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        instance = serializer.save(creator=request.user)
        return Response(
            SessionSerializer(instance, context={'request': request}).data,
            status=status.HTTP_201_CREATED
        )


class CreatorSessionDetailView(generics.RetrieveUpdateDestroyAPIView):
    """Creator: manage a specific session."""
    permission_classes = [IsCreatorOrReadOnly]

    def get_serializer_class(self):
        if self.request.method in ('PUT', 'PATCH'):
            return SessionCreateUpdateSerializer
        return SessionSerializer

    def get_queryset(self):
        return Session.objects.filter(creator=self.request.user)

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        instance = serializer.save()
        return Response(
            SessionSerializer(instance, context={'request': request}).data
        )


class CreatorBookingsOverviewView(APIView):
    """Creator: see all bookings for their sessions."""
    permission_classes = [IsCreator]

    def get(self, request):
        from apps.bookings.models import Booking
        from apps.bookings.serializers import BookingSerializer
        bookings = Booking.objects.filter(
            session__creator=request.user
        ).select_related('session', 'user').order_by('-booked_at')
        serializer = BookingSerializer(bookings, many=True)
        return Response(serializer.data)
