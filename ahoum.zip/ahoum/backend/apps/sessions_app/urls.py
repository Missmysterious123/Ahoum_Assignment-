from django.urls import path
from .views import (
    SessionListView,
    SessionDetailView,
    CreatorSessionListCreateView,
    CreatorSessionDetailView,
    CreatorBookingsOverviewView,
)

urlpatterns = [
    path('', SessionListView.as_view(), name='session-list'),
    # Creator routes — MUST come before <int:pk>/ to avoid conflicts
    path('my/', CreatorSessionListCreateView.as_view(), name='creator-sessions'),
    path('my/bookings/', CreatorBookingsOverviewView.as_view(), name='creator-bookings'),
    path('my/<int:pk>/', CreatorSessionDetailView.as_view(), name='creator-session-detail'),
    # Public detail
    path('<int:pk>/', SessionDetailView.as_view(), name='session-detail'),
]
