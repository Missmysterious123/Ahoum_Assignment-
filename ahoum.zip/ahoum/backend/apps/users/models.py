from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    ROLE_USER = 'user'
    ROLE_CREATOR = 'creator'
    ROLE_CHOICES = [
        (ROLE_USER, 'User'),
        (ROLE_CREATOR, 'Creator'),
    ]

    email = models.EmailField(unique=True)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default=ROLE_USER)
    avatar = models.URLField(blank=True, null=True)
    bio = models.TextField(blank=True, null=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    def __str__(self):
        return self.email

    @property
    def is_creator(self):
        return self.role == self.ROLE_CREATOR
