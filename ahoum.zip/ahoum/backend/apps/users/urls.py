from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import GoogleAuthCallbackView, ProfileView, SwitchRoleView

urlpatterns = [
    path('google/callback/', GoogleAuthCallbackView.as_view(), name='google-callback'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token-refresh'),
    path('profile/', ProfileView.as_view(), name='profile'),
    path('switch-role/', SwitchRoleView.as_view(), name='switch-role'),
]
