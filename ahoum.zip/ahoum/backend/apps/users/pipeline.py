def save_profile(backend, user, response, *args, **kwargs):
    """Save Google profile picture to user avatar."""
    if backend.name == 'google-oauth2':
        avatar = response.get('picture')
        if avatar and not user.avatar:
            user.avatar = avatar
            user.save()
