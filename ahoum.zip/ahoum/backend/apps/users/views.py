from django.conf import settings
import requests
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken
from .models import User
from .serializers import UserSerializer, UserUpdateSerializer


def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    refresh['role'] = user.role
    refresh['email'] = user.email
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


class GoogleAuthCallbackView(APIView):
    """
    Exchange Google authorization code for backend JWT.
    Frontend sends: { code, redirect_uri }
    Backend exchanges with Google, finds/creates user, returns JWT.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        code = request.data.get('code')
        redirect_uri = request.data.get('redirect_uri')

        if not code:
            return Response({'error': 'Code is required'}, status=status.HTTP_400_BAD_REQUEST)

        # Exchange code for Google tokens
        token_response = requests.post('https://oauth2.googleapis.com/token', data={
            'code': code,
            'client_id': settings.SOCIAL_AUTH_GOOGLE_OAUTH2_KEY,
            'client_secret': settings.SOCIAL_AUTH_GOOGLE_OAUTH2_SECRET,
            'redirect_uri': redirect_uri,
            'grant_type': 'authorization_code',
        })

        if token_response.status_code != 200:
            return Response({'error': 'Failed to exchange code with Google'},
                            status=status.HTTP_400_BAD_REQUEST)

        google_tokens = token_response.json()
        access_token = google_tokens.get('access_token')

        # Fetch user info from Google
        userinfo_response = requests.get(
            'https://www.googleapis.com/oauth2/v3/userinfo',
            headers={'Authorization': f'Bearer {access_token}'}
        )

        if userinfo_response.status_code != 200:
            return Response({'error': 'Failed to fetch user info from Google'},
                            status=status.HTTP_400_BAD_REQUEST)

        userinfo = userinfo_response.json()
        email = userinfo.get('email')
        name = userinfo.get('name', '')
        avatar = userinfo.get('picture', '')
        given_name = userinfo.get('given_name', '')
        family_name = userinfo.get('family_name', '')

        if not email:
            return Response({'error': 'Email not provided by Google'},
                            status=status.HTTP_400_BAD_REQUEST)

        # Get or create the user
        user, created = User.objects.get_or_create(
            email=email,
            defaults={
                'username': email.split('@')[0],
                'first_name': given_name,
                'last_name': family_name,
                'avatar': avatar,
            }
        )

        if not created and avatar and not user.avatar:
            user.avatar = avatar
            user.save()

        tokens = get_tokens_for_user(user)
        return Response({
            'tokens': tokens,
            'user': UserSerializer(user).data,
        })


class ProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response(UserSerializer(request.user).data)

    def patch(self, request):
        serializer = UserUpdateSerializer(request.user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(UserSerializer(request.user).data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SwitchRoleView(APIView):
    """Allow users to switch between User and Creator roles."""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        new_role = request.data.get('role')
        if new_role not in [User.ROLE_USER, User.ROLE_CREATOR]:
            return Response({'error': 'Invalid role'}, status=status.HTTP_400_BAD_REQUEST)
        request.user.role = new_role
        request.user.save()
        tokens = get_tokens_for_user(request.user)
        return Response({
            'tokens': tokens,
            'user': UserSerializer(request.user).data,
        })
